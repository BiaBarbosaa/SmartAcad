

import './cliente.css'
import Navbar from '../../template/Navbar';
import Sidebar from '../../template/Sidebar';
import MainCadastroCliente from '../../MainCadastroCliente'

<<<<<<< HEAD:React/start/src/components/paginas/cliente/CadastrarCliente.jsx
function CadastrarCliente() {
=======
function                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            EditarAluno() {
>>>>>>> c0b2b06cab1952100675ffb2503a5f35fd325ada:React/start/src/components/paginas/aluno/EditarAluno.jsx
    return (
        <>
            <Navbar />
            <div className="container-fluid">
                <div className="row">
                    <Sidebar />
                    <MainCadastroCliente />

                </div>
            </div>
        </ >
    );
}
export default CadastrarCliente;