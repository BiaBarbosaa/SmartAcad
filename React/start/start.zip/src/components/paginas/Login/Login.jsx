
import MainLogin from '../../MainLogin';

function Login() {
    return (
        <>

            <MainLogin />


        </ >
    );
}
export default Login;